module connect4 {
	requires javafx.fxml;
	requires javafx.controls;
	
	opens application;
}